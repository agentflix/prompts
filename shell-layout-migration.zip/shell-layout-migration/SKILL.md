# Shell Layout Migration Skill

> Skill para migrar qualquer tela existente para o padrão ShellLayout do SuporteFY.
> Dois padrões suportados: **Modal** (edição inline) e **Form** (navegação para página dedicada).

---

## 1. Quando usar cada padrão

| Critério | Modal | Form Page |
|---|---|---|
| Campos do formulário | ≤ 6 campos simples | ≥ 7 campos ou complexos |
| Seções distintas | Não | Sim (abas, seções) |
| Upload de arquivos | Não | Sim |
| Fluxo multi-step | Não | Sim |
| Entidade principal do sistema | Não | Sim |
| Deve ter URL própria | Não | Sim |

**Regra de ouro:** se o formulário "cabe" em 480px de largura sem scroll, use Modal. Se precisa de espaço, use Form Page.

---

## 2. Prompt de Migração — USE ESTE TEMPLATE

Cole no chat adaptando os campos entre `<`:

```
Migre a tela <NOME_DA_TELA> em <ARQUIVO_ATUAL> para o padrão ShellLayout SuporteFY.

**Padrão:** <MODAL | FORM>

**Entidade:** <nome da entidade, ex: "cliente", "produto", "ticket">

**Campos do formulário:**
- <campo>: <tipo> — <obrigatório/opcional>
- <campo>: <tipo> — <obrigatório/opcional>

**Colunas da tabela:**
- <campo>: <estilo — ex: "código mono azul", "nome bold", "muted", "badge status">

**Status possíveis:** <active/inactive/pending | ativo/inativo/rascunho | etc>

**Rota base:** /admin/<rota>

Siga EXATAMENTE o padrão definido em .claude/skills/shell-layout-migration/SKILL.md.
Não invente nada fora do padrão. Valide cada item do checklist antes de concluir.
```

---

## 3. Padrão A — Modal

### Estrutura de arquivos

```
src/components/shared/<Entidade>/
  <Entidade>ListDemo.tsx    ← tabela + GigaModal + confirm delete
src/pages/
  <Entidade>Page.tsx        ← wrapper: <div className="p-6 bg-muted/20 min-h-full">
```

### Componentes obrigatórios

```tsx
// ── GigaModal (NUNCA usar shadcn Dialog direto)
import * as DialogPrimitive from '@radix-ui/react-dialog';

function GigaModal({ open, onOpenChange, title, children, footer }) {
  return (
    <DialogPrimitive.Root open={open} onOpenChange={onOpenChange}>
      <DialogPrimitive.Portal>
        <DialogPrimitive.Overlay className="fixed inset-0 z-50 bg-black/45 ..." />
        <DialogPrimitive.Content className="fixed left-1/2 top-1/2 z-50 w-[480px] max-w-[calc(100vw-2rem)] -translate-x-1/2 -translate-y-1/2 overflow-hidden rounded-lg bg-card shadow-[0_24px_64px_rgba(0,0,0,0.18)] ...">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-border px-[22px] py-[18px]">
            <DialogPrimitive.Title className="text-base font-bold text-foreground">{title}</DialogPrimitive.Title>
            <DialogPrimitive.Close className="rounded-md p-1 text-muted-foreground ...">
              <X className="h-[18px] w-[18px]" />
            </DialogPrimitive.Close>
          </div>
          {/* Body */}
          <div className="flex flex-col gap-4 p-[22px]">{children}</div>
          {/* Footer */}
          <div className="flex items-center justify-end gap-[10px] border-t border-border bg-background px-[22px] py-[14px]">
            {footer}
          </div>
        </DialogPrimitive.Content>
      </DialogPrimitive.Portal>
    </DialogPrimitive.Root>
  );
}
```

### Estrutura interna do modal (campos)

```tsx
{/* Campo com prefixo Search (ex: buscar cliente) */}
<div className="flex flex-col gap-[5px]">
  <Label className="text-xs font-semibold text-muted-foreground">Nome do campo</Label>
  <Input prefix={<Search className="h-3.5 w-3.5" />} placeholder="..." />
</div>

{/* Grid 2 colunas */}
<div className="grid grid-cols-2 gap-[14px]">
  <div className="flex flex-col gap-[5px]">
    <Label className="text-xs font-semibold text-muted-foreground">Código</Label>
    <Input disabled value={editingItem?.code ?? ''} placeholder="Automático" />
  </div>
  <div className="flex flex-col gap-[5px]">
    <Label className="text-xs font-semibold text-muted-foreground">Status</Label>
    <Select>...</Select>
  </div>
</div>

{/* Campo com sufixo Calendar */}
<Input suffix={<Calendar className="h-3.5 w-3.5" />} placeholder="dd/mm/aaaa" />

{/* Textarea com hint */}
<div className="flex flex-col gap-[5px]">
  <Label className="text-xs font-semibold text-muted-foreground">Observações</Label>
  <Textarea className="resize-none bg-card text-[13px]" rows={3} />
  <span className="text-[11px] text-muted-foreground">Texto de ajuda aqui</span>
</div>
```

### Modal de confirmação de exclusão (obrigatório)

```tsx
<GigaModal title="Excluir <entidade>" ...>
  <div className="flex items-start gap-4">
    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-danger-bg text-danger">
      <AlertTriangle className="h-5 w-5" />
    </div>
    <div>
      <p className="text-[13px] text-foreground leading-relaxed">
        Tem certeza que deseja excluir <strong>"{item?.name}"</strong>?
      </p>
      <p className="mt-1 text-[13px] text-muted-foreground">
        Essa ação não pode ser desfeita.
      </p>
    </div>
  </div>
</GigaModal>
```

---

## 4. Padrão B — Form Page

### Estrutura de arquivos

```
src/components/shared/<Entidade>/
  <Entidade>ListDemo.tsx         ← tabela SEM modal; handleEdit navega
src/pages/
  <Entidade>Page.tsx             ← wrapper lista
  <Entidade>FormPage.tsx         ← página de formulário full-page
AdminRoute.tsx                   ← sub-rotas: /base/novo e /base/edit/:id
```

### Página de formulário — estrutura obrigatória

```tsx
export default function <Entidade>FormPage() {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const isEditing = !!id;

  return (
    <div className="p-6 bg-muted/20 min-h-full">

      {/* Breadcrumb */}
      <div className="mb-1.5 flex items-center gap-1.5 text-[12px] text-muted-foreground">
        <span>Home</span><span>/</span>
        <button onClick={() => navigate('/admin/<rota>')} className="hover:text-foreground transition-colors">
          <Entidade>s
        </button>
        <span>/</span>
        <span className="text-foreground font-medium">{isEditing ? 'Editar' : 'Novo'}</span>
      </div>

      {/* Header */}
      <div className="mb-5 flex items-center gap-3">
        <button onClick={() => navigate('/admin/<rota>')}
          className="flex h-8 w-8 items-center justify-center rounded-[6px] border border-border bg-card text-muted-foreground hover:bg-muted hover:text-foreground transition-colors">
          <ArrowLeft className="h-4 w-4" />
        </button>
        <h1 className="text-[18px] font-bold leading-tight text-foreground">
          {isEditing ? 'Editar <entidade>' : 'Nova <entidade>'}
        </h1>
      </div>

      {/* Form card — SEMPRE w-full */}
      <div className="rounded-lg border border-border bg-card overflow-hidden w-full">

        {/* Card header */}
        <div className="border-b border-border px-[22px] py-[18px]">
          <h2 className="text-[14px] font-semibold text-foreground">Dados da <entidade></h2>
          <p className="text-[12px] text-muted-foreground mt-0.5">Descrição breve.</p>
        </div>

        {/* Card body */}
        <div className="flex flex-col gap-5 p-[22px]">
          {/* campos — mesmas regras do modal */}
        </div>

        {/* Card footer */}
        <div className="flex items-center justify-end gap-[10px] border-t border-border bg-background px-[22px] py-[14px]">
          <Button variant="ghost" onClick={() => navigate('/admin/<rota>')}>Cancelar</Button>
          <Button onClick={handleSave}>
            <Save className="mr-1.5 h-4 w-4" />
            {isEditing ? 'Salvar alterações' : 'Criar <entidade>'}
          </Button>
        </div>
      </div>
    </div>
  );
}
```

### Rotas no AdminRoute.tsx

```tsx
<Route path="<rota>" element={<EntidadeListPage />} />
<Route path="<rota>/novo" element={<EntidadeFormPage />} />
<Route path="<rota>/edit/:id" element={<EntidadeFormPage />} />
```

---

## 5. Padrão de tabela — SEMPRE seguir

```tsx
// Coluna: código/ID
cell: (row) => <span className="font-mono text-[12px] font-semibold text-primary">{row.code}</span>

// Coluna: nome principal
cell: (row) => <span className="font-medium text-foreground">{row.name}</span>

// Coluna: valor monetário
cell: (row) => <span className="font-semibold text-foreground">{row.price}</span>

// Coluna: texto secundário (data, email, categoria)
cell: (row) => <span className="text-muted-foreground">{row.email}</span>

// Coluna: status badge
cell: (row) => <ShellStatusBadge value={row.status} options={STATUS_OPTIONS} />

// Coluna: actions — SEMPRE 3 ícones inline
{
  id: 'actions', header: '', width: '84px',
  cell: (row) => (
    <div className="flex items-center gap-0">
      <ActionBtn title="Editar" onClick={() => handleEdit(row)}><SquarePen size={14} /></ActionBtn>
      <ActionBtn title="Copiar" onClick={() => ...}><Copy size={14} /></ActionBtn>
      <DropdownMenu>
        <DropdownMenuTrigger asChild><span><ActionBtn title="Mais opções"><MoreHorizontal size={14} /></ActionBtn></span></DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-40">
          <DropdownMenuItem>...</DropdownMenuItem>
          <DropdownMenuItem className="text-danger focus:text-danger">Excluir</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  ),
}
```

### ActionBtn (copie exatamente)

```tsx
function ActionBtn({ onClick, title, children }: { onClick?: () => void; title: string; children: React.ReactNode }) {
  return (
    <button type="button" title={title} onClick={onClick}
      className="flex cursor-pointer items-center justify-center rounded-[5px] p-[4px] text-muted-foreground transition-colors hover:bg-muted hover:text-foreground">
      {children}
    </button>
  );
}
```

---

## 6. Tokens CSS proibidos / obrigatórios

| Situação | ERRADO | CERTO |
|---|---|---|
| Fundo de inputs | `bg-white`, `bg-background` | `bg-card` |
| Fundo de offcanvas | default | `bg-card` |
| Label de campo | qualquer outro | `text-xs font-semibold text-muted-foreground` |
| Header de modal | padding livre | `px-[22px] py-[18px]` |
| Body de modal | padding livre | `p-[22px]` |
| Footer de modal/card | qualquer fundo | `bg-background px-[22px] py-[14px]` |
| Sombra do modal | shadow-md, shadow-xl | `shadow-[0_24px_64px_rgba(0,0,0,0.18)]` |
| Overlay | bg-black/50, bg-black/80 | `bg-black/45` |
| Gap entre campos no grid | gap-4, gap-3 | `gap-[14px]` |
| Gap label→input | gap-2, gap-1 | `gap-[5px]` |
| Hint text | text-xs text-gray-500 | `text-[11px] text-muted-foreground` |
| Status badge | badges custom | `<ShellStatusBadge>` |
| Form card width | max-w-2xl, max-w-3xl | `w-full` |

---

## 7. Checklist de Validação Anti-Drift

Execute este checklist ANTES de marcar a migração como concluída.

### 7.1 Estrutura geral

- [ ] `ShellLayout` recebe `title`, `entityName`, `breadcrumb`, `data`, `columns`, `statusOptions`
- [ ] `onCreate` e `onEdit` definidos e funcionais
- [ ] `onBulkDelete` implementado com `toast`
- [ ] `searchableFields` inclui os campos relevantes
- [ ] `pagination` configurado com `page`, `pageSize`, `total`, `onPageChange`
- [ ] Wrapper page usa `<div className="p-6 bg-muted/20 min-h-full">`

### 7.2 Tabela

- [ ] Coluna de ID/código usa `font-mono text-[12px] font-semibold text-primary`
- [ ] Coluna de nome usa `font-medium text-foreground`
- [ ] Campos secundários usam `text-muted-foreground`
- [ ] Coluna actions tem exatamente 3 ícones: SquarePen + Copy + MoreHorizontal
- [ ] `MoreHorizontal` abre dropdown com "Ver detalhes" + "Excluir" (text-danger)
- [ ] `ActionBtn` usa `rounded-[5px] p-[4px]`

### 7.3 Modal (padrão A)

- [ ] Usa `@radix-ui/react-dialog` primitivos DIRETAMENTE (não shadcn Dialog)
- [ ] Overlay: `bg-black/45`
- [ ] Content: `w-[480px] max-w-[calc(100vw-2rem)] rounded-lg bg-card shadow-[0_24px_64px_rgba(0,0,0,0.18)]`
- [ ] Header: `px-[22px] py-[18px]` com título bold + X
- [ ] Body: `flex flex-col gap-4 p-[22px]`
- [ ] Footer: `bg-background px-[22px] py-[14px]` com Cancelar (ghost) + Confirmar
- [ ] Labels: `text-xs font-semibold text-muted-foreground`
- [ ] Gap label→input: `gap-[5px]`
- [ ] Grid 2-col usa `gap-[14px]`
- [ ] Modal de confirm exclusão existe com `AlertTriangle` + `bg-danger-bg text-danger`
- [ ] Inputs têm `bg-card` (não transparentes)

### 7.4 Form Page (padrão B)

- [ ] Breadcrumb clicável com `hover:text-foreground transition-colors`
- [ ] Back button: `h-8 w-8 rounded-[6px] border border-border bg-card`
- [ ] `ArrowLeft` icon no back button
- [ ] Card: `w-full` (NUNCA max-w-*)
- [ ] Card header: `border-b border-border px-[22px] py-[18px]`
- [ ] Card body: `flex flex-col gap-5 p-[22px]`
- [ ] Card footer: `bg-background px-[22px] py-[14px]` com Cancelar (ghost) + Salvar (primary com `<Save>` icon)
- [ ] Rotas `/novo` e `/edit/:id` registradas em AdminRoute.tsx
- [ ] `handleEdit` usa `navigate(`/admin/<rota>/edit/${id}`)` 
- [ ] `handleCreate` usa `navigate('/admin/<rota>/novo')`
- [ ] Formulário NÃO abre modal — navega para nova página

### 7.5 Tokens e CSS

- [ ] Nenhum input com `bg-white` ou `bg-background` (usar `bg-card`)
- [ ] Offcanvas de filtros tem `bg-card` no SheetContent
- [ ] `--radius: 0.375rem` em `src/index.css`
- [ ] Nenhum `console.log` em produção (só `toast`)

### 7.6 Após migração

- [ ] `npx tsc --noEmit` sem erros
- [ ] CHANGELOG atualizado em `CHANGELOG-YYYY-MM-DD.md`
- [ ] Imports não usados removidos

---

## 8. Erros comuns de drift

| Drift | Sintoma | Correção |
|---|---|---|
| shadcn Dialog no lugar de DialogPrimitive | Modal com estrutura fora do padrão | Trocar por `@radix-ui/react-dialog` primitivos |
| Fundo transparente nos inputs | Inputs "somem" no tema claro | Adicionar `bg-card` |
| Form card com max-w | Card não ocupa 100% | Trocar por `w-full` |
| Footer do card sem `bg-background` | Footer com fundo errado | Adicionar `bg-background` |
| Sem modal de confirm exclusão | Clique em Excluir deleta direto | Implementar GigaModal de confirmação |
| Labels sem `text-xs font-semibold` | Labels com tamanho/peso errado | Corrigir para o padrão |
| gap-4 no grid em vez de gap-[14px] | Espaçamento ligeiramente errado | Corrigir para `gap-[14px]` |
| ActionBtn inline com className diferente | Ícones com hover errado | Usar ActionBtn exatamente como definido |
