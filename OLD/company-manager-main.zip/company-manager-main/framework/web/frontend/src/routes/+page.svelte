<script lang="ts">
  import CapturePanel from '$lib/components/CapturePanel.svelte';
</script>

<CapturePanel />
