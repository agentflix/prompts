<script lang="ts">
  import ConversationPanel from '$lib/components/ConversationPanel.svelte';
</script>

<ConversationPanel />
