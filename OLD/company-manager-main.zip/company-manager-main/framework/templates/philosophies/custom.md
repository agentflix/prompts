# Custom

> **summary:** Esqueleto em branco — escreva sua propria filosofia ou misture varias.

## Princípios chave

-

## Estrutura de tasks

## Vocabulário

## Agentes arquetípicos

## Cadência sugerida
